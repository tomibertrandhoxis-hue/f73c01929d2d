// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Query over HTTPS"); }
int main(){
  announce();
  return lionss_run_workload("dns-doh");
}
