// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Specialize generics"); }
int main(){
  announce();
  return lionss_run_workload("scala-specialize");
}
