// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Resync RAID array\n", stdout);
  return lionss_run_workload("raid-resync");
}
