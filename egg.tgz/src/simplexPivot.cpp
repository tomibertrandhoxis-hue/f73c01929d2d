// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Pivot to optimum\n", stdout);
  return lionss_run_workload("simplexPivot");
}
