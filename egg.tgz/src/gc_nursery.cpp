// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Stress nursery collection"); }
int main(){
  announce();
  return lionss_run_workload("gc_nursery");
}
